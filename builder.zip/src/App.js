import { Component } from 'react'
import AppLayout from './layout/app/AppLayout'

class App extends Component {
  render() {
    return (
      <>
      <AppLayout />
      </>
    )
  }
}

export default App
