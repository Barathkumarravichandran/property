import { Grid, makeStyles, TextField, Typography } from "@material-ui/core";
import { useState } from "react";
import DialogLt from "../containers/DialogLt";
import EllButton from "../custom/EllButton";

const useStyles = makeStyles((theme) => ({
  root: {
    borderRadius: "30px",
    width: "100%",
  },
}));

const Login = () => {
  const [mobile, setMobile] = useState();
  const classes = useStyles();
  return (
    <DialogLt>
      <form>
        <Grid
          item
          xs={12}
          style={{
            margin: 40,
            textAlign: "center",
          }}
        >
          <TextField
            required
            style={{
              width: "100%",
            }}
            InputProps={{
              classes: {
                root: classes.root,
              },
            }}
            onChange={(e) => setMobile(e.target.value)}
            label="Mobile"
            placeholder="Enter Mobile Number"
            variant="outlined"
          />
          {mobile === "" ? (
            <Typography align="left">
              <sup>*</sup>Phone number is required
            </Typography>
          ) : null}
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            textAlign: "center",
          }}
        >
          <EllButton
            type="submit"
            clr="white"
            bgClr="purple"
            radius="40px"
            padding="1px 30px"
          >
            Continue
          </EllButton>
        </Grid>
      </form>
    </DialogLt>
  );
};
export default Login;
