import { Grid, Typography } from "@material-ui/core";
import EllButton from "../custom/EllButton";

const UserRole = () => {
  return (
    <>
      <Grid
        style={{
          marginTop: 40,
        }}
        item
        xs={12}
      >
        <Typography align="center" variant="h5">
          Login as
        </Typography>
        <Typography
          style={{
            opacity: 0.7,
            fontSize: 16,
          }}
          align="center"
          variant="body1"
        >
          which type of user you are
        </Typography>
      </Grid>
      <Grid item>
        <Grid
          style={{
            marginTop: 40,
          }}
          container
          direction="row"
          align="center"
          justify="center"
        >
          <Grid item xs={12} sm={3}>
            <Grid container direction="column">
              <Grid item>
                <EllButton
                  type="submit"
                  variant="contained"
                  color="primary"
                  radius="40px"
                  padding="1px 50px"
                >
                  User
                </EllButton>
              </Grid>

              <Grid item>
                <Typography
                  style={{
                    margin: "auto 20px",
                  }}
                  variant="caption"
                >
                  Role you choose
                </Typography>
                <br />
                <Typography
                  style={{
                    margin: "auto 20px",
                  }}
                  variant="caption"
                >
                  to buy Property
                </Typography>
              </Grid>
            </Grid>
          </Grid>

          <Grid item xs={12} sm={3} style={{ 
              marginLeft : "20px",
          }}>
            <Grid container direction="column">
              <Grid item>
                <EllButton
                color="primary"
                  type="submit"
                  variant="outlined"
                  radius="40px"
                  padding="1px 50px"
                >
                  Builder
                </EllButton>
              </Grid>

              <Grid item>
                <Typography
                  style={{
                    margin: "auto 20px",
                  }}
                  variant="caption"
                >
                  Role you choose
                </Typography>
                <br />
                <Typography
                  style={{
                    margin: "auto 20px",
                  }}
                  variant="caption"
                >
                  to buy Property
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default UserRole;
