import { Grid, makeStyles, TextField, Typography } from "@material-ui/core";
import { useState } from "react";
import EllButton from "../custom/EllButton";

const useStyles = makeStyles((theme) => ({
  root: {
    borderRadius: "30px",
    width: "100%",
  },
}));
const UserForm = ({ setStep, setRole }) => {
  const classes = useStyles();

  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [mobile, setMobile] = useState();
  return (
    <div>
      <form>
        <Grid
          item
          xs={12}
          style={{
            margin: "5px 40px",
            textAlign: "center",
          }}
        >
          <TextField
            required
            style={{
              width: "100%",
            }}
            InputProps={{
              classes: {
                root: classes.root,
              },
            }}
            onChange={(e) => setName(e.target.value)}
            label="Name"
            placeholder="Enter Name"
            variant="outlined"
          />
          {name === "" ? (
            <Typography align="left">
              <sup>*</sup>Name is required
            </Typography>
          ) : null}
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            margin: "5px 40px",
            textAlign: "center",
          }}
        >
          <TextField
            required
            style={{
              width: "100%",
            }}
            InputProps={{
              classes: {
                root: classes.root,
              },
            }}
            onChange={(e) => setEmail(e.target.value)}
            label="E-Mail"
            placeholder="Enter E-Mail"
            variant="outlined"
          />
          {email === "" ? (
            <Typography align="left">
              <sup>*</sup>E-Mail is required
            </Typography>
          ) : null}
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            margin: "5px 40px",
            textAlign: "center",
          }}
        >
          <TextField
            required
            style={{
              width: "100%",
            }}
            InputProps={{
              classes: {
                root: classes.root,
              },
            }}
            onChange={(e) => setMobile(e.target.value)}
            label="Mobile"
            placeholder="Enter Mobile Number"
            variant="outlined"
          />
          {mobile === "" ? (
            <Typography align="left">
              <sup>*</sup>Phone number is required
            </Typography>
          ) : null}
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            margin: "10px 40px",
            textAlign: "center",
          }}
        >
          <EllButton
            type="submit"
            clr="white"
            bgClr="purple"
            radius="40px"
            padding="1px 30px"
            onClick={() => {
              setStep(2);
              setRole(false);
            }}
          >
            Continue
          </EllButton>
        </Grid>
      </form>
    </div>
  );
};

export default UserForm;
