import { useState } from "react";
import DialogLt from "../containers/DialogLt";
import UserForm from "./UserForm";
import UserRole from "./UserRole";

const Register = () => {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState(true);
  const switchStep = () => {
    switch (step) {
      case 1:
        return <UserForm setStep={setStep} setRole={setRole} />;
      case 2:
        return <UserRole />;
      default:
        return;
    }
  };

  return <DialogLt role={role ? true : false}>{switchStep()}</DialogLt>;
};

export default Register;
