import { Grid, Typography } from "@material-ui/core";
import Logo from "../../assets/Logo.png";
import Google from "../../assets/icons/google.svg";
import Facebook from "../../assets/icons/facebook.svg";
import EllButton from "../custom/EllButton";
import LogoImg from "../custom/LogoImg";

const DialogLt = ({ children, role }) => {
  return (
    <>
      <div
        style={{
          margin: "10px",
        }}
      >
        <Grid container direction="column">
          <Grid
            item
            xs
            style={{
              textAlign: "center",
            }}
          >
            <img
              src={Logo}
              alt="heading"
              style={{
                width: "50%",
                height: "100px",
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <Typography align="center" variant="subtitle1">
              Robust suite of tools for buyers, sellers, landlords, renters,
              agents, and other home professionals.
            </Typography>
          </Grid>
        </Grid>
        {children}
        {role ? (
          <>
            {" "}
            <Grid item style={{ textAlign: "center", margin: 20 }}>
              <Typography>
                There is always a social way to connect with us
              </Typography>
            </Grid>
            <Grid container direction="row">
              <Grid item xs={12} sm={6}>
                <EllButton radius="50px" padding="10px" variant="outlined">
                  <LogoImg
                    margin="0 20px 0 -20px"
                    width="70px"
                    height="25px"
                    src={Google}
                    alt="Google"
                  />
                  <Typography style={{ marginLeft: "-30px " }}>
                    Connect with Google
                  </Typography>
                </EllButton>
              </Grid>
              <Grid item xs={12} sm={6}>
                <EllButton radius="50px" padding="10px" variant="outlined">
                  <LogoImg
                    margin="0 20px 0 -20px"
                    width="70px"
                    height="25px"
                    src={Facebook}
                    alt="Facebook"
                  />
                  <Typography style={{ marginLeft: "-30px " }}>
                    Connect with Facebook
                  </Typography>
                </EllButton>
              </Grid>
            </Grid>{" "}
          </>
        ) : null}
      </div>
    </>
  );
};

export default DialogLt;
