import { Button } from "@material-ui/core";

const EllButton = ({ variant, clr, bgClr, children, radius, padding, ...other }) => {
  return (
    <>
      <Button
        variant={variant}
        style={{
          backgroundColor: bgClr,
          color: clr,
          textTransform: "capitalize",
          borderRadius: radius,
          fontSize: 20,
          padding: padding,
        }}
        {...other}
      >
        {children}
      </Button>
    </>
  );
};
export default EllButton;
