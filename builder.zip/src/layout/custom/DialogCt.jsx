import PropTypes from "prop-types";
import { Dialog, DialogContent, IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";

const DialogCt = (props) => {
  const { onClose, children, open } = props;

  const handleClose = () => {
    onClose();
  };

  return (
    <Dialog
      style={{
        height: "650px",
        marginTop: "-40px",
      }}
      disableBackdropClick
      onClose={handleClose}
      aria-labelledby="simple-dialog-title"
      open={open}
    >
      <IconButton
        onClick={handleClose}
        style={{
          width: "auto",
          right: 0,
          position: "absolute",
        }}
      >
        <CloseIcon />
      </IconButton>
      <DialogContent>{children}</DialogContent>
    </Dialog>
  );
};

DialogCt.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
};

export default DialogCt;
