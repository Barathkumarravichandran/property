const LogoImg = ({ margin, width, height, src, alt }) => {
  return (
    <>
      <img
        style={{
          margin: margin,
          width: width,
          height: height,
        }}
        src={src}
        alt={alt}
      />
    </>
  );
};

export default LogoImg;
