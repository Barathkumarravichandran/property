import { Toolbar, List, ListItem, Typography } from "@material-ui/core";
import { useState } from "react";
import Login from "../components/Login";
import Register from "../components/Register";
import DialogCt from "../custom/DialogCt";

const AppHeader = () => {
  const [loginState, setLoginState] = useState(false);
  const [registerState, setRegisterState] = useState(false);

  return (
    <>
      <Toolbar
        style={{
          backgroundColor: "royalblue",
          color: "white",
          justifyContent: "flex-end",
        }}
      >
        <List
          style={{
            display: "flex",
          }}
        >
          <ListItem onClick={() => setLoginState(true)}>
            <Typography
              style={{
                fontWeight: "600",
              }}
              variant="h5"
            >
              Login
            </Typography>
          </ListItem>
          <ListItem onClick={() => setRegisterState(true)}>
            <Typography
              style={{
                fontWeight: "600",
              }}
              variant="h5"
            >
              Register
            </Typography>
          </ListItem>
        </List>
      </Toolbar>

      <DialogCt open={loginState} onClose={() => setLoginState(false)}>
        <Login />
      </DialogCt>
      <DialogCt open={registerState} onClose={() => setRegisterState(false)}>
        <Register />
      </DialogCt>
    </>
  );
};
export default AppHeader;
