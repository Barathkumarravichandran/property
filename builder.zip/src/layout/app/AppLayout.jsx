import { Grid } from "@material-ui/core";
import AppHeader from "./AppHeader";

const AppLayout = () => {
  return (
    <>
      <Grid container>
        <Grid item xs={12}>
          <AppHeader />
        </Grid>
      </Grid>
    </>
  );
};
export default AppLayout;
